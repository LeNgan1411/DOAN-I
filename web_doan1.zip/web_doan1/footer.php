 <footer id="fo">
        <div class="container">
            <div class="row">
                <div class="col-lg-8 text-address">
                    <div class="name"><img src="./public/images/logo-bottom.jpg" alt=""></div>
                    <div class="address">Phòng 405 - C9, Đại học Bách Khoa Hà Nội, số 1 Đại Cồ Việt, Hai Bà Trưng, Hà
                        Nội</div>
                </div>
                <div class="col-lg-4 copy-right">Copyright © 2021 Viện Điện tử - Viễn thông.</div>
            </div>
        </div>
    </footer>
    
</body>
</html>