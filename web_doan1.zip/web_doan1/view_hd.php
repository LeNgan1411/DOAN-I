
<table border="1">
<tr>
<td>ID</td>
<td>Ten hd</td>
<td>Thoi han</td>
</tr>
<?php
 require "db_conn.php";
if ($conn){
        mysqli_close($conn);
    }
$conn = mysqli_connect("localhost","root","","demo");
// Check connection
if (mysqli_connect_errno())
{
echo "Failed to connect to MySQL: " . mysqli_connect_error();
}
	$sql = "select * from kehoach where 1   ";
    
    // Thực hiện câu truy vấn
    $query = mysqli_query($conn, $sql);
    
    // Mảng chứa kết quả
    $result = array();
    
    // Lặp qua từng record và đưa vào biến kết quả
    if ($query){
        while ($row = mysqli_fetch_assoc($query)){
            $result[] = $row;
        }

    }
    var_dump($result);
    var_dump($row);
?>
<tr>
<td><?php echo $result['id']; ?></td>
<td><?php echo $result['ten_hd']; ?></td>
<td><?php echo $result['thoi_han']; ?></td>
<td><a href="edit_user.php?id=<?php echo $row['id']; ?>">Edit</a></td>
<td><a href="delete_user.php?id=<?php echo $row['id']; ?>">Delete</a></td>
</tr>
<?php

?>
</table>
